PASSWORD_TEST = 'superSecurePassword2020'

singup_data = {
    "password": PASSWORD_TEST,
    "password_confirmation": PASSWORD_TEST,
    "first_name": "manaos",
    "last_name": "manaos",
    "gender": "M",
    # "city": 1,
    "phone_number": "1234567890",
    "phone_region_code": "+1",
    "email": "manaos@mail.com",
    "username": "manaos@mail.com"
}

login_data = {
    "email": "manaos@mail.com",
    "password": PASSWORD_TEST,
}
